const mainMenu = {
    keyboard:[
        [{text:"Поиск заведений"},{text:"Настройка фильтра"}],
        [{text:"Сброс фильтра"}],
    ],
    inline_keyboard:[],
    resize_keyboard: true,
    one_time_keyboard: true
}

const filterMenu = {
    inline_keyboard:[
        [{text:"Выбрать геопозицию 🌇",             callback_data:"/filter_geo"}],
        [{text:"Выбрать заведение 🏠",              callback_data:"/filter_place"}],
        [{text:"Выбрать средний чек 💸",            callback_data:"/filter_price"}],
        [{text:"Выбрать кухню 🍲",                  callback_data:"/filter_kitchen"}],
        [{text:"Выбрать рейтинг ✨",                callback_data:"/filter_sort"}],
        [{text:"Вернуться в главное меню ⏪",       callback_data:"/start"}],
    ],
    resize_keyboard: true,
    one_time_keyboard: true
}

const geoKeyboard = {
    keyboard:[
        [{text:"Поделиться позицией",    request_location:true}],
        [{text:"Отмена"}]
    ],
    resize_keyboard: true,
    one_time_keyboard: true
}

const placeKeyboard = {
    keyboard:[
        [{text:"Кафе"},{text:"Кофейни"}],
        [{text:"Рестораны"},{text:"Пиццерии"}],
        [{text:"Быстрое питание"},{text:"Суши-бары"}],
        [{text:"Столовые"},{text:"Отмена"}]
    ],
    resize_keyboard: true,
    one_time_keyboard: true
}

const priceKeyboard = {
    keyboard:[
        [{text:"100-400"},{text:"400-700"},{text:"700-1000"}],
        [{text:"1000-1300"},{text:"1300-1600"},{text:"1600-2000"}],
        [{text:"2000-2300"},{text:"Отмена"}],
    ],
    resize_keyboard: true,
    one_time_keyboard: true
}

const kitchenKeyboard = {
    keyboard:[
        [{text:"Русская"},{text:"Японская"}],
        [{text:"Европейская"},{text:"Итальянская"}],
        [{text:"Отмена"}]

    ],
    resize_keyboard: true,
    one_time_keyboard: true
}

const sortKeyboard = {
    keyboard:[
        [{text:"1"},{text:"2"},{text:"3"},{text:"4"},{text:"5"}],
        [{text:"Отмена"}]
    ],
    resize_keyboard: true,
    one_time_keyboard: true
}

module.exports = {
    mainMenu,
    filterMenu,
    geoKeyboard,
    placeKeyboard,
    priceKeyboard,
    kitchenKeyboard,
    sortKeyboard
}