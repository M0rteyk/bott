const BOT           = require("node-telegram-bot-api")
const TOKEN         = "6155632945:AAENfwuIRXFuqcQr2hO9107in0f1nK7STE8"

const bot = new BOT(TOKEN,{polling:true})

const createUser    = require("./user")
let users           = {}

bot.setMyCommands([
    {command:"/start",description:"Старт/Сброс"}
])
bot.on('callback_query', async msg =>{
console.log(msg)
    const chat_id = msg.message.chat.id
    bot.answerCallbackQuery(msg.id, 'Вы выбрали: '+ msg.data, false);
    if(users[chat_id])
        users[chat_id].wait(msg)
})
bot.on('message', async msg=>{
    const chat_id = msg.chat.id
    if(!users[chat_id])
        users[chat_id] = createUser(msg,bot)
    users[chat_id].wait(msg)
})

