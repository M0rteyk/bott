const API_KEY_MAP   = "4e5a1d66-9a25-4e00-aa6f-b8eed923ab43"
const API_KEY_INF   = "ruwuwf4634"

const all_data = {
    "place":{
        "Кафе":161,
        "Кофейни":162,
        "Рестораны":164,
        "Столовые":166,
        "Суши-бары":15791,
        "Пиццерии":51459,
        "Быстрое питание":165
    },
    "kitchen":{
        "Европейская":"food_service_food_european",
        "Итальянская":"food_service_food_italian",
        "Авторская":"food_service_food_exquisite",
        "Азиатская":"food_service_food_asian",
        "Американская":"food_service_food_american",
        "Вегетарианская":"food_service_food_vegetariancuisine",
        "Восточная":"food_service_food_oriental",
        "Чешская":"food_service_food_czech",
        "Японская":"food_service_food_japanese",
        "Халяльная":"food_service_food_hal",
        "Французская":"food_service_food_french",
        "Украинская":"food_service_food_ukrainian",
        "Узбекская":"food_service_food_uzbek",
        "Татарская":"food_service_food_tatar",
        "Средиземноморская":"food_service_food_mediterranean",
        "Рыбная":"food_service_food_fish",
        "Русская":"food_service_food_russian",
        "Пан-азиатская":"food_service_food_pan_asian",
        "Кавказская":"food_service_food_caucasian",
        "Еврейская":"food_service_food_jewish",
        "Домашняя":"food_service_food_domestic",
        "Грузинская":"food_service_food_georgian"
    }
}

const {
    mainMenu,
    filterMenu,
    geoKeyboard,
    placeKeyboard,
    priceKeyboard,
    kitchenKeyboard,
    sortKeyboard
} = require("./keyboards")

const createUser = (msg,bot) => {
    return new User(msg,bot)
}

class User{

    constructor(msg,bot){
        this.id     = msg.chat.id
        this.name   = msg.chat.first_name
        this.snam   = msg.chat.last_name

        this.menuPosition   = "main"
        this.wait           = this.command
        this.bot            = bot

        this.town           = undefined
        this.place          = undefined
        this.price          = undefined
        this.kitchen        = undefined
        this.sort           = undefined
    }

    async command(msg){
        if(msg.text)
            switch(msg.text){
                case "/start":{
                    this.wait = this.textCommand
                    return this.bot.sendMessage(this.id,`${dayTime(msg.date)}, ${this.name} ${this.snam}!`,{
                        reply_markup: mainMenu
                    })
                }
                default:{
                    return this.bot.sendMessage(this.id,"Такой команды нет! Используйте команду из меню!")
                }
            }

        this.error()
    }
       
    async textCommand(msg){
        if(msg.text)
            switch(msg.text){
                case "/start":{
                    this.wait = this.textCommand
                    return this.bot.sendMessage(this.id,`${dayTime(msg.date)}, ${this.name} ${this.snam}!`,{
                        reply_markup: mainMenu
                    })
                }
                case "Поиск заведений":{
                    if(!this.town || !this.town.point || !this.place){
                        await this.bot.sendMessage(this.id,"Заполните необходимые поля фильтра!")
                        this.viewFilter()
                        return
                    }else{
                        let url = `https://catalog.api.2gis.com/3.0/items?q=Поесть&sort=distance&fields=items.ads.options,items.org,items.contact_groups,items.schedule,tems.point,items.reviews&radius=20000&rubric_id=${all_data.place[this.place]}&sort_point=${this.town.point[0]},${this.town.point[1]}&key=${API_KEY_INF}`
                        
                        if(this.price)
                            url += `&attr[food_service_avg_price]=${this.price}`

                        if(this.kitchen)
                            url += `&attr[${all_data.kitchen[this.kitchen]}]=true`

                        console.log(url)
                        let data 
                        await fetch(url)
                            .then(response => response.json())
                            .then(json => data = json)
                        
                        if(data.code && data.code == 404){
                            await this.bot.sendMessage(this.id,`Результатов по данному фильру не найдено.`)
                            this.viewFilter()
                            return
                        }

                        let sortint = {}
                        let rate_sorting = []
                        if(data.result.items){
                            data = data.result.items
                            for(const item of data){
                                if(item.reviews.general_rating <= this.sort)
                                    continue

                                if(!sortint[item.reviews.general_rating])
                                    sortint[item.reviews.general_rating] = []

                                if(!rate_sorting.includes(item.reviews.general_rating))
                                    rate_sorting.push(item.reviews.general_rating)
                                sortint[item.reviews.general_rating].push(item)
                            }
                            rate_sorting.sort((a, b) => b - a)
                        }
                        this.botSendPlace(sortint,rate_sorting)
                    }
                    return
                }
                case "Настройка фильтра":{
                    this.viewFilter()
                    return
                }
                case "Сброс фильтра":{
                    this.town           = undefined
                    this.place          = undefined
                    this.price          = undefined
                    this.kitchen        = undefined
                    this.sort           = undefined
                    this.viewFilter()
                    return
                }
                case "Кафе":
                case "Кофейни":
                case "Рестораны":
                case "Столовые":
                case "Суши-бары":
                case "Пиццерии":
                case "Быстрое питание":{
                    this.place = msg.text 
                    this.viewFilter()
                    return
                }
                case "100-400":
                case "400-700":
                case "700-1000":
                case "1000-1300":
                case "1300-1600":
                case "1600-2000":
                case "2000-2300":{
                    this.price = msg.text.replace("-",",")
                    this.viewFilter()
                    return
                }
                case "Русская":
                case "Японская":
                case "Европейская":
                case "Итальянская":{
                    this.kitchen = msg.text
                    this.viewFilter()
                    return
                }
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":{
                    this.sort = msg.text
                    this.viewFilter()
                    return
                }
                case "Отмена":{
                    this.viewFilter()
                    return
                }
                default:{
                    let town = {}
                    let data

                    await fetch(`https://catalog.api.2gis.com/3.0/items/geocode?q=${msg.text}&fields=items.point&type=adm_div.city&key=${API_KEY_INF}`)
                        .then(response => response.json())
                        .then(json => data = json.result)

                    if(data){
                        data = data.items[0].point
                        const lat = data.lat
                        const lon = data.lon
                        await fetch(`https://catalog.api.2gis.com/3.0/items/geocode?lon=${lon}&lat=${lat}&fields=items.point&key=${API_KEY_INF}`)
                            .then(response => response.json())
                            .then(json => data = json.result.items)
                        for(const item of data){
                            if(["region","city","district",].includes(item.subtype))
                                town[item.subtype] = item.full_name
                            
                            town["point"] = [lon,lat]
                        }
                        this.town = town
                        this.viewFilter()
                        return                       
                    }

                    return this.bot.sendMessage(this.id,"Такой команды нет! Используйте команду из меню!")
                }
            }

        if(msg.location){
            let town = {}
            let data
            await fetch(`https://catalog.api.2gis.com/3.0/items/geocode?lon=${msg.location.longitude}&lat=${msg.location.latitude}&fields=items.point&key=${API_KEY_INF}`)
                .then(response => response.json())
                .then(json => data = json.result.items)

            for(const item of data){
                if(["region","city","district",].includes(item.subtype))
                    town[item.subtype] = item.full_name
                town["point"] = [msg.location.longitude,msg.location.latitude]
            }
            this.town = town
            this.viewFilter()
            return
        }
        
        this.error()
    }

    async botSendPlace(sortint,rate_sorting){
        let limit = 5
        const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
        const day  = days[new Date().getDay()]
        await this.bot.sendMessage(this.id,"Перечень:\n",{
            reply_markup:JSON.stringify({remove_keyboard: true}),
            parse_mode:"html"
        })
        for(const rater of rate_sorting){
            for(const item of sortint[rater]){
                // const work_time = item.schedule[day].working_hours
                // График работы на сегодня: ${work_time[0].from} - ${work_time[0].to}
                if(limit == 0)
                    break
                limit--
                let html = `${item.reviews.general_rating?"⭐"+item.reviews.general_rating:""} ${item.name} 
    ${item.address_name}, ${item.address_comment?item.address_comment:""}
`
                if(item.schedule){
                    if(item.schedule[day]){
                       const work_time = item.schedule[day].working_hours
                       html += `   График работы на сегодня: ${work_time[0].from} - ${work_time[0].to}
`
                    }
                }
                
                let keyboard = {
                    parse_mode:"html"
                }


                if(item.ads && item.ads.options && item.ads.options.actions){
                    if(item.ads.options.actions[0].type == "phone")
                        html += `   Номер: <a href='tel:${item.ads.options.actions[0].value}'>${item.ads.options.actions[0].value}</a>\n`
                    if(item.ads.options.actions[0].type == "link"){
                        let url = item.ads.options.actions[0].value
                        url = url.substr(url.indexOf("https://"))
                        html += `   Сайт:  <a href='${url}'>${item.ads.options.actions[0].name}</a>\n`
                    }
                }
                
                await this.bot.sendMessage(this.id,html,keyboard)
                
                await this.sleep(500)
            } 
            if(limit == 0)
                break
        }                
        await this.bot.sendMessage(this.id,"Ничего не понравилось, можно настроить фильтр по другому и попробовать ещё раз! 😊",{
            reply_markup:mainMenu
        })
        return
    }
    
    async sleep(ms) {
        return new Promise((resolve) => {
            setTimeout(resolve, ms);
        });
    }

    async queryCommand(msg){
        if(msg.data)
            switch(msg.data){
                case "/start":{
                    this.wait = this.textCommand
                    return this.bot.sendMessage(this.id,`${dayTime(msg.message.date)}, ${this.name} ${this.snam}!`,{
                        reply_markup: mainMenu
                    })
                }
                case "/filter_geo":{
                    this.wait = this.textCommand
                    return this.bot.sendMessage(this.id,`🌇 Введите название города или поделитесь геопозицией!`,{
                        reply_markup:geoKeyboard
                    })
                }
                case "/filter_place":{
                    this.wait = this.textCommand
                    return this.bot.sendMessage(this.id,`🏠 Выберете желаемый тип заведения!`,{
                        reply_markup:placeKeyboard
                    })
                }
                case "/filter_price":{
                    this.wait = this.textCommand
                    return this.bot.sendMessage(this.id,`💸 Выберете средний чек!`,{
                        reply_markup:priceKeyboard
                    })
                }
                case "/filter_kitchen":{
                    this.wait = this.textCommand
                    return this.bot.sendMessage(this.id,`🍲 Выберете кухню!`,{
                        reply_markup:kitchenKeyboard
                    })
                }
                case "/filter_sort":{
                    this.wait = this.textCommand
                    return this.bot.sendMessage(this.id,`✨ Выберете рейтинг!`,{
                        reply_markup:sortKeyboard
                    })
                }
                default:{
                    return this.bot.sendMessage(this.id,"Такой команды нет! Используйте команду из меню!")
                }
            }
        this.error()
    }
        
    async viewFilter(){
        let html = ``
        await this.bot.sendMessage(this.id,'Текущие настройки:',{
            reply_markup:JSON.stringify({remove_keyboard: true})
        })
        if(this.town){
            html += `Положение:\n`
            html += this.town.region?`    Регион:     ${this.town.region}.\n`:""
            html += this.town.city?`    Город:      ${this.town.city}.\n`:""
            html += this.town.district?`    Район:      ${this.town.district}.\n`:""
            html += `    Координаты: ${this.town.point[0]} - ${this.town.point[1]}.\n`
        }else{
            html += `Положение: не задано.(Обязательно)\n`
        }

        if(this.place){
            html += `Заведение:      ${this.place}.\n`
        }else{
            html += `Заведение:      не задано.(Обязательно)\n`
        }

        if(this.price){
            html += `Средний чек:    ${this.price}.\n`
        }else{
            html += `Средний чек:    не задано.\n`
        }

        if(this.kitchen){
            html += `Кухня:          ${this.kitchen}.\n`
        }else{
            html += `Кухня:          не задано.\n`
        }

        if(this.sort){
            html += `Рейтинг:        выше или равен ${this.sort}.\n`
        }else{
            html += `Рейтинг:        не задано.\n`
        }

        this.wait = this.queryCommand

        return this.bot.sendMessage(this.id,html,{
            reply_markup: filterMenu,
            parse_mode:"html"
        })
    }

    async error(){
        this.wait = this.queryCommand
        return this.bot.sendMessage(this.id,"Просим прощения, но на стороне сервера, что-то пошло не так!",{
            reply_markup:JSON.stringify({
                inline_keyboard:[
                    [{text:"Вернуться в главное меню ⏪",callback_data:"/start"}]
                ],
            })
        })
    }

}

const day_time_str = [
    [["07","10"],   "Доброе утро"],
    [["10","15"],   "Добрый день"],
    [["15","23"],   "Добрый вечер"],
    [["23","03"],   "Доброй ночи"],
    [["03","07"],   "Раннее утро"],
]

const dayTime = (unix_timestamp)=>{
    const time_c = new Date(unix_timestamp*1000)
    
    const hello_str = day_time_str.find((item)=>{
        
        const year      = time_c.getFullYear()
        const mont      = time_c.getMonth()
        const date      = time_c.getDate()
        const hour_c    = time_c.getHours()

        let date_s      = date   
        let date_e      = date
        if(Number(item[0][1]) < Number(item[0][0])){
            if(Number(hour_c) >= Number(item[0][0])){
                date_s = date
                date_e = Number(date) + 1
            }else{
                date_s = Number(date) - 1
                date_e = date
            }
        }

        const time_s    = new Date(year,mont,date_s,item[0][0],0,0,0)
        const time_e    = new Date(year,mont,date_e,item[0][1],0,0,0)

        if(time_s <= time_c && time_c < time_e){
            return item
        }         
    })
    
    if(hello_str[1])
        return hello_str[1]

    return "Здравствуйте"
}

module.exports = createUser











// if(item.contact_groups){
                //     html += `Наши контакты:\n`
                //     for(const contact of item.contact_groups){
                //         if(!contact.contacts)
                //             continue
                //         const links = contact.contacts
                //         for(const link of links){
                //             if(link.type == "phone")
                //                 html += `   Номер: <a href='tel:${link.value}'>${link.text}</a>\n`
                //             if(link.type == "website")
                //                 html += `   Сайт:  <a href='${link.url}'>${link.text}</a>\n`
                //             if(link.type == "email")
                //                 html += `   Почта: ${link.value}\n`
                //             if(link.type == "vkontakte")
                //                 html += `   ВКонтакте: <a href='${link.url}'>${link.url.replace("https://vk.com/","")}</a>\n`
                //             if(link.type == "telegram")
                //                 html += `   Телеграм:  <a href='${link.url}'>${link.url.replace("https://t.me/","")}</a>\n`
                //         }
                //         html += `\n`
                //     }
                // }